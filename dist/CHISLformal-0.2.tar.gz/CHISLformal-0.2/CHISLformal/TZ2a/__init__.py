"""
:authors: Fedor987

:Functions: 
    Различные действия с матрицами
    
    
"""
from .TZ2 import *

__author__ = 'Fedor987'
__version__ = '0.2'

