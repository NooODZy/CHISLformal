"""
:authors: Fedor987

:Functions: 
    Ршения задачи оптимизации методом отжига
    
    
"""
from .TZ7Otjig import *

__author__ = 'Fedor987'
__version__ = '0.2'

