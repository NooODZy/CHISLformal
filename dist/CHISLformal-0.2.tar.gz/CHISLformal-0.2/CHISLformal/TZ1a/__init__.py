"""
:authors: Fedor987

:Functions: 
    Содержит различные функции численного интегрирования (различные способы)
    
    
    
"""
from .TZ1 import *

__author__ = 'Fedor987'
__version__ = '0.2'

