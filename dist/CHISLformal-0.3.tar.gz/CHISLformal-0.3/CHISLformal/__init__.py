"""
:authors: Fedor987

:Functions: 
    В библиотеке представлены готовые задания 1-8 по предмету "Числовые методы"

"""

from .TZ1a import *
from .TZ2a import *
from .TZ3a import *
from .TZ6a import *
from .TZ7Otjiga import *
from .TZ8Antsa import *

__author__ = 'Fedor987'
__version__ = '0.2'

print("""В вышепредставленных моудлях содержится код для решения различных задач""")

