"""
:authors: Fedor987

:Functions: 
    Функция решает задачу оптимизации методом муравьев
    
    
"""
from .TZ8Ants import *

__author__ = 'Fedor987'
__version__ = '0.3'

